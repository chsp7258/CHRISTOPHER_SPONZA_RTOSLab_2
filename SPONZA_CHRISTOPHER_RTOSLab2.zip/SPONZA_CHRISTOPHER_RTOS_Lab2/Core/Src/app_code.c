/**
  ******************************************************************************
  * @file    app_code.c
  * @author  Christopher Sponza
  * @brief   Application Code module driver.
  ******************************************************************************
**/
#include "Gyro_Driver.h"
#include "app_code.h"

int USER_BTN = 0;
int16_t velocity = 0;
typedef_GYRO_RATE GYRO_RATE = SLOW_CW;
volatile static int systic_count = 0;


/**
  * @brief  initialize the peripherals for the application layer
  * @retval none
  */
void app_init()
{
	Gyro_Init();
	interrupt_init();
}


/**
  * @brief  enable NVIC IRQs required by application layer
  * @retval none
  */
void interrupt_init()
{
	HAL_NVIC_EnableIRQ(EXTI0_IRQn);
	HAL_NVIC_EnableIRQ(SysTick_IRQn);
}


/**
  * @brief  Update the state of the LEDs based on gyro rotation rate and user button state
  * @retval none
  */
void USER_BTN_State()
{
	USER_BTN = HAL_GPIO_ReadPin(USER_BTN_PORT, USER_BTN_PIN);
}


/**
  * @brief  Update the state of the LEDs based on gyro rotation rate and user button state
  * @retval none
  */
void GyroRate()
{
	GYRO_RATE = SLOW_CW;							//re-initialize the gyro rate to SLOW_CW
	velocity = Gyro_Get_Velocity();
	/*
	 * change the GYRO_RATE global variable enum based on the value of velocity returned from
	 * Gyro_Get_Velocity()
	 */
	if (velocity > 500 && velocity < 5000)
	{
		GYRO_RATE = SLOW_CW;
	}
	if (velocity >= 5000)
	{
		GYRO_RATE = FAST_CW;
	}
	if (velocity < -500 && velocity > -5000)
	{
		GYRO_RATE = SLOW_CCW;
	}
	if (velocity <= -5000)
	{
		GYRO_RATE = FAST_CCW;
	}
}

/**
  * @brief  Update the state of the LEDs based on gyro rotation rate and user button state
  * @retval none
  */
void changeLED()
{
	/*
	 * turn on the GREEN LED if the user button is depressed otherwise both LEDs should
	 * initially be off
	 */
	if (USER_BTN)
	{
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, HIGH);
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, LOW);
	}
	else
	{
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, LOW);
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, LOW);
	}
	/*
	 * Turn on the green LED for CCW rotation of the gyro
	 * Turn on the red LED for CW rotation with the user button depressed
	 */
	switch(GYRO_RATE)
	{
	case SLOW_CW:
		if (USER_BTN)
		{
			HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, HIGH);
		}
		break;
	case FAST_CW:
		if (USER_BTN)
		{
			HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, HIGH);
		}
		break;
	case SLOW_CCW:
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, HIGH);
		break;
	case FAST_CCW:
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, HIGH);
		break;
	}
}

/**
  * @brief  increments the systic count. If 100 ms has passed sample the gyro rate, update
  * the LEDs, and reset the counter
  * @retval none
  */
void HAL_SYSTICK_Callback()
{
	systic_count++;								//update the systic counter
	if (systic_count%HUND_MS == 0)				//if 100ms has passed sample the gyro and update the LED state
	{
		GyroRate();
		changeLED();
		systic_count = 0;						//reset the counter
	}
}

/**
  * @brief  update the state of the USER_BTN global and update the states of the LEDs
  * @retval none
  */
void EXTI0_IRQHandler()
{
	USER_BTN_State();
	changeLED();
}
