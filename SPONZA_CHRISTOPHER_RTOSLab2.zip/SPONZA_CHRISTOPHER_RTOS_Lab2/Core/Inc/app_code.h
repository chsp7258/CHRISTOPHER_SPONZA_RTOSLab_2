/**
  ******************************************************************************
  * @file    app_code.h
  * @author  Christopher Sponza
  * @brief   Header file of application module.
  ******************************************************************************
**/

#ifndef INC_APP_CODE_H_
#define INC_APP_CODE_H_

#define USER_BTN_PORT						GPIOA
#define USER_BTN_PIN						GPIO_PIN_0

#define GREEN_LED_PORT						GPIOG
#define GREEN_LED_PIN						GPIO_PIN_13


#define RED_LED_PORT						GPIOG
#define RED_LED_PIN							GPIO_PIN_14

#define	HIGH								1
#define LOW									0

#define HUND_MS								100

#define LAB2_USE_INTERRUPT					0

typedef enum
{
	SLOW_CW, FAST_CW, SLOW_CCW, FAST_CCW
}typedef_GYRO_RATE;

void app_init();

void interrupt_init();

void USER_BTN_State();

void GyroRate();

void changeLED();

void HAL_Systick_Callback();

void EXTI0_IRQHandler();

#endif /* INC_APP_CODE_H_ */
